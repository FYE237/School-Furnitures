export class TransactionModel{
    constructor( 
            public acheteur: string,
            public vendeur: string,
            public achat:string,
            public photo:string,
            public prix:string,
            public date:string,
        ){} 

}